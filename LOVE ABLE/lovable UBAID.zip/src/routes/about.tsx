import { createFileRoute, Link } from "@tanstack/react-router";
import craft from "@/assets/craft.jpg";
import bed from "@/assets/bed.jpg";
import desk from "@/assets/desk.jpg";
import dining from "@/assets/dining.jpg";
import chair from "@/assets/chair.jpg";
import { PageHero } from "@/components/site/SiteChrome";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Our Story — Faradini Furniture" },
      { name: "description", content: "The story, craftsmanship, materials and vision behind Faradini Furniture." },
      { property: "og:title", content: "Our Story — Faradini Furniture" },
      { property: "og:description", content: "The story, craftsmanship and vision behind Faradini Furniture." },
    ],
  }),
  component: About,
});

const blocks = [
  { t: "Our Story", img: dining, text: "Faradini began with a simple belief: furniture should be made to be lived with, loved and passed on. What started as a small workshop has grown into a house of design known for warmth, character and quiet luxury." },
  { t: "Our Craftsmanship", img: craft, text: "Every piece is shaped by skilled artisans who combine traditional joinery with modern precision. Hand-carved details, hand-rubbed finishes and meticulous inspection define every Faradini creation." },
  { t: "Our Materials", img: chair, text: "We work with responsibly sourced solid hardwoods, full-grain leathers, fine natural fabrics and solid brass hardware — materials chosen for their beauty and how gracefully they age." },
  { t: "Our Vision", img: desk, text: "To create timeless interiors where modern design and enduring craft meet — furniture that elevates everyday living and becomes part of a family's story." },
  { t: "Our Commitment to Customers", img: bed, text: "From the first conversation to delivery and installation, we offer personal guidance, honest advice and dependable after-care. Your satisfaction is the final finish on every piece." },
];

function About() {
  return (
    <>
      <PageHero eyebrow="About Faradini" title="Crafted With Intention" text="Premium materials, skilled hands and modern design — brought together for beautiful living." image={craft} />
      <section className="mx-auto max-w-7xl space-y-28 px-6 pb-28">
        {blocks.map((b, i) => (
          <div key={b.t} className="grid items-center gap-12 md:grid-cols-2">
            <Reveal className={i % 2 ? "md:order-2" : ""}>
              <img src={b.img} alt={b.t} loading="lazy" className="aspect-[4/3] w-full rounded-md object-cover" />
            </Reveal>
            <Reveal delay={150}>
              <p className="eyebrow">0{i + 1}</p>
              <h2 className="mt-3 text-4xl text-cream md:text-5xl">{b.t}</h2>
              <p className="mt-6 text-lg leading-relaxed text-muted-foreground">{b.text}</p>
            </Reveal>
          </div>
        ))}
        <Reveal className="text-center">
          <Link to="/shop" className="btn-gold">Explore the Collection</Link>
        </Reveal>
      </section>
    </>
  );
}
