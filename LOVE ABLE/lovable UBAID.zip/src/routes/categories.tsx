import { createFileRoute, Link } from "@tanstack/react-router";
import wardrobe from "@/assets/wardrobe.jpg";
import { categories, products } from "@/data/products";
import { PageHero } from "@/components/site/SiteChrome";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/categories")({
  head: () => ({
    meta: [
      { title: "Furniture Categories — Faradini" },
      { name: "description", content: "Living room, bedroom, dining, office, custom furniture and home décor by Faradini." },
      { property: "og:title", content: "Furniture Categories — Faradini" },
      { property: "og:description", content: "Explore Faradini furniture by room and style." },
    ],
  }),
  component: Categories,
});

function Categories() {
  return (
    <>
      <PageHero eyebrow="Categories" title="Furnish Every Room" text="Explore our collections by space — each designed with the same uncompromising craft." image={wardrobe} />
      <section className="mx-auto max-w-7xl space-y-6 px-6 pb-28">
        {categories.map((c, i) => {
          const count = products.filter((p) => p.category === c.name).length;
          return (
            <Reveal key={c.name}>
              <Link to="/shop" search={{ category: c.name }} className={`group grid overflow-hidden rounded-md border bg-card transition-colors hover:border-gold/50 md:grid-cols-2 ${i % 2 ? "md:[&>*:first-child]:order-2" : ""}`}>
                <div className="aspect-[16/10] overflow-hidden">
                  <img src={c.image} alt={c.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                </div>
                <div className="flex flex-col justify-center p-10 md:p-14">
                  <p className="eyebrow">0{i + 1}</p>
                  <h2 className="mt-3 text-4xl text-cream md:text-5xl">{c.name}</h2>
                  <p className="mt-4 text-muted-foreground">{c.blurb}</p>
                  <p className="mt-8 text-xs font-semibold uppercase tracking-[0.25em] text-gold">{count ? `View ${count} piece${count > 1 ? "s" : ""}` : "Enquire"} →</p>
                </div>
              </Link>
            </Reveal>
          );
        })}
      </section>
    </>
  );
}
