import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { Minus, Plus, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import { products, formatPrice, whatsappLink } from "@/data/products";
import { ProductCard } from "@/components/site/ProductCard";

export const Route = createFileRoute("/product/$id")({
  loader: ({ params }) => {
    const product = products.find((p) => p.id === params.id);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "Not found — Faradini" }, { name: "robots", content: "noindex" }] };
    const p = loaderData.product;
    return {
      meta: [
        { title: `${p.name} — Faradini Furniture` },
        { name: "description", content: p.short },
        { property: "og:title", content: `${p.name} — Faradini Furniture` },
        { property: "og:description", content: p.short },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="py-48 text-center">
      <h1 className="text-4xl text-cream">Product not found</h1>
      <Link to="/shop" className="btn-gold mt-8">Back to Shop</Link>
    </div>
  ),
  component: ProductPage,
});

function ProductPage() {
  const { product: p } = Route.useLoaderData();
  const [img, setImg] = useState(0);
  const [color, setColor] = useState(0);
  const [qty, setQty] = useState(1);
  const related = products.filter((x) => x.id !== p.id).slice(0, 3);
  const msg = `Hello Faradini, I'm interested in the ${p.name} (${p.colors[color].name}, qty ${qty}).`;

  return (
    <div key={p.id} className="mx-auto max-w-7xl px-6 pb-28 pt-32">
      <nav className="mb-8 text-xs uppercase tracking-[0.2em] text-muted-foreground">
        <Link to="/shop" className="hover:text-gold">Shop</Link> / <span className="text-gold">{p.name}</span>
      </nav>
      <div className="grid gap-12 lg:grid-cols-2">
        <div>
          <div className="aspect-square overflow-hidden rounded-md border">
            <img src={p.gallery[img]} alt={p.name} className="h-full w-full object-cover" />
          </div>
          <div className="mt-4 grid grid-cols-4 gap-3">
            {p.gallery.map((g, i) => (
              <button key={i} onClick={() => setImg(i)} className={`aspect-square overflow-hidden rounded-sm border-2 ${i === img ? "border-gold" : "border-transparent opacity-60 hover:opacity-100"}`} aria-label={`Image ${i + 1}`}>
                <img src={g} alt="" loading="lazy" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
        </div>
        <div>
          <p className="eyebrow">{p.category}</p>
          <h1 className="mt-3 text-5xl text-cream md:text-6xl">{p.name}</h1>
          <p className="mt-4 text-2xl text-gold">{formatPrice(p.price)}</p>
          <p className="mt-6 leading-relaxed text-muted-foreground">{p.description}</p>
          <dl className="mt-8 grid grid-cols-2 gap-6 border-y py-6 text-sm">
            <div><dt className="eyebrow !text-[0.6rem]">Material</dt><dd className="mt-2 text-cream">{p.material}</dd></div>
            <div><dt className="eyebrow !text-[0.6rem]">Dimensions</dt><dd className="mt-2 text-cream">{p.dimensions}</dd></div>
          </dl>
          <div className="mt-8">
            <p className="eyebrow !text-[0.6rem]">Colour — <span className="text-cream">{p.colors[color].name}</span></p>
            <div className="mt-3 flex gap-3">
              {p.colors.map((c, i) => (
                <button key={c.name} onClick={() => setColor(i)} aria-label={c.name} className={`h-9 w-9 rounded-full border-2 ${i === color ? "border-gold" : "border-border"}`} style={{ background: c.value }} />
              ))}
            </div>
          </div>
          <div className="mt-8 flex items-center gap-4">
            <p className="eyebrow !text-[0.6rem]">Quantity</p>
            <div className="flex items-center rounded-md border">
              <button onClick={() => setQty(Math.max(1, qty - 1))} className="p-3 text-cream hover:text-gold" aria-label="Decrease"><Minus size={14} /></button>
              <span className="w-10 text-center text-cream">{qty}</span>
              <button onClick={() => setQty(qty + 1)} className="p-3 text-cream hover:text-gold" aria-label="Increase"><Plus size={14} /></button>
            </div>
          </div>
          <div className="mt-10 flex flex-wrap gap-4">
            <button onClick={() => toast.success("Order request received", { description: "Our team will contact you shortly to confirm details." })} className="btn-gold">Request Order</button>
            <a href={whatsappLink(msg)} target="_blank" rel="noreferrer" className="btn-outline-gold"><MessageCircle size={16} /> WhatsApp Inquiry</a>
          </div>
        </div>
      </div>
      <section className="mt-28">
        <h2 className="mb-10 text-4xl text-cream">You May Also Like</h2>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {related.map((r) => <ProductCard key={r.id} product={r} />)}
        </div>
      </section>
    </div>
  );
}
