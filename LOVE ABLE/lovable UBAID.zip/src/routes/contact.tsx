import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Phone, Mail, MapPin, Clock, MessageCircle } from "lucide-react";
import sofa from "@/assets/sofa.jpg";
import { CONTACT, whatsappLink } from "@/data/products";
import { PageHero } from "@/components/site/SiteChrome";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Faradini Furniture — Visit Our Showroom" },
      { name: "description", content: "Get in touch with Faradini Furniture by phone, WhatsApp or email, or visit our showroom." },
      { property: "og:title", content: "Contact Faradini Furniture" },
      { property: "og:description", content: "Reach Faradini by phone, WhatsApp or email, or visit our showroom." },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = useState(false);
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    toast.success("Message sent", { description: "Thank you — our team will be in touch shortly." });
    e.currentTarget.reset();
    setSent(true);
  };
  const info = [
    { icon: Phone, label: "Phone", value: CONTACT.phone },
    { icon: Mail, label: "Email", value: CONTACT.email },
    { icon: MapPin, label: "Showroom", value: CONTACT.address },
    { icon: Clock, label: "Business Hours", value: CONTACT.hours },
  ];
  return (
    <>
      <PageHero eyebrow="Contact" title="Let's Create Together" text="Questions, custom requests or a showroom visit — we'd love to hear from you." image={sofa} />
      <section className="mx-auto grid max-w-7xl gap-12 px-6 pb-28 lg:grid-cols-5">
        <form onSubmit={submit} className="glass space-y-5 rounded-md p-8 md:p-10 lg:col-span-3">
          <h2 className="text-3xl text-cream">Send a message</h2>
          <div className="grid gap-5 md:grid-cols-2">
            <input required name="name" placeholder="Name" maxLength={100} className="field" aria-label="Name" />
            <input required name="phone" type="tel" placeholder="Phone" maxLength={30} className="field" aria-label="Phone" />
          </div>
          <input required name="email" type="email" placeholder="Email" maxLength={255} className="field" aria-label="Email" />
          <textarea required name="message" rows={6} placeholder="Message" maxLength={1000} className="field resize-none" aria-label="Message" />
          <button type="submit" className="btn-gold w-full md:w-auto">Send Message</button>
          {sent && <p className="text-sm text-gold">Thank you — we'll reply soon.</p>}
        </form>
        <aside className="space-y-6 lg:col-span-2">
          {info.map((i) => (
            <div key={i.label} className="flex gap-4 border-b pb-6">
              <i.icon className="mt-1 text-gold" size={20} strokeWidth={1.4} />
              <div>
                <p className="eyebrow !text-[0.6rem]">{i.label}</p>
                <p className="mt-2 text-cream">{i.value}</p>
              </div>
            </div>
          ))}
          <a href={whatsappLink()} target="_blank" rel="noreferrer" className="btn-gold w-full"><MessageCircle size={16} /> Chat on WhatsApp</a>
        </aside>
      </section>
    </>
  );
}
