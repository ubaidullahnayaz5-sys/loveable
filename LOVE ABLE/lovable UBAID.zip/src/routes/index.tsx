import { createFileRoute, Link } from "@tanstack/react-router";
import { Gem, Hammer, Sparkles, Headset, Star } from "lucide-react";
import hero from "@/assets/hero.jpg";
import craft from "@/assets/craft.jpg";
import dining from "@/assets/dining.jpg";
import { products, categories } from "@/data/products";
import { ProductCard } from "@/components/site/ProductCard";
import { Reveal, SectionHeading } from "@/components/site/Reveal";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Faradini Furniture — Luxury Furniture for Beautiful Living" },
      { name: "description", content: "Premium handcrafted sofas, beds, dining tables and custom furniture by Faradini." },
      { property: "og:title", content: "Faradini Furniture — Luxury Furniture for Beautiful Living" },
      { property: "og:description", content: "Premium handcrafted sofas, beds, dining tables and custom furniture by Faradini." },
    ],
  }),
  component: Index,
});

const features = [
  { icon: Gem, title: "Premium Quality Materials", text: "Solid hardwoods, full-grain leathers and fine fabrics, sourced with care." },
  { icon: Hammer, title: "Expert Craftsmanship", text: "Every joint and finish shaped by skilled hands with decades of experience." },
  { icon: Sparkles, title: "Modern & Timeless Designs", text: "Contemporary lines rooted in classic proportion — never out of season." },
  { icon: Headset, title: "Reliable Customer Service", text: "Guidance from first idea to final installation, and long after." },
];

const reviews = [
  { name: "Ayesha Rahman", role: "Lahore", text: "The dining table is breathtaking. Guests always ask where it's from — the craftsmanship is on another level." },
  { name: "Daniel Whitmore", role: "Dubai", text: "Our custom wardrobe fits the room perfectly. The team was attentive at every step of the process." },
  { name: "Sara Malik", role: "Karachi", text: "Elegant, comfortable and beautifully finished. Faradini turned our living room into a sanctuary." },
];

function Index() {
  return (
    <>
      {/* HERO */}
      <section className="relative flex min-h-screen items-center overflow-hidden">
        <img src={hero} alt="Luxury walnut living room with leather sofa" width={1920} height={1088} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-background/10" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
        <div className="pointer-events-none absolute -left-40 -top-40 h-[36rem] w-[36rem] rounded-full bg-gold/20 blur-[120px]" />
        <div className="relative mx-auto w-full max-w-7xl px-6 pt-24">
          <Reveal>
            <p className="eyebrow">Faradini Furniture</p>
            <h1 className="mt-6 max-w-3xl text-6xl leading-[0.95] text-cream md:text-8xl">
              Crafting Comfort.<br />
              <span className="italic text-gold-gradient">Creating Elegance.</span>
            </h1>
            <p className="mt-8 max-w-md text-lg text-muted-foreground">Premium furniture designed for beautiful living.</p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link to="/shop" className="btn-gold">Explore Collection</Link>
              <Link to="/contact" className="btn-outline-gold">Contact Us</Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* FEATURED */}
      <section className="mx-auto max-w-7xl px-6 py-28">
        <SectionHeading eyebrow="Featured Collection" title="Signature Pieces" text="A curated selection of our most loved designs, each made to be lived with for a lifetime." />
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((p, i) => (
            <Reveal key={p.id} delay={(i % 3) * 120}><ProductCard product={p} /></Reveal>
          ))}
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="bg-wood-gradient py-28">
        <div className="mx-auto max-w-7xl px-6">
          <SectionHeading eyebrow="Furniture Categories" title="Furnish Every Room" />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {categories.map((c, i) => (
              <Reveal key={c.name} delay={(i % 3) * 100}>
                <Link to="/shop" search={{ category: c.name }} className="group relative block aspect-[4/3] overflow-hidden rounded-md border">
                  <img src={c.image} alt={c.name} loading="lazy" className="h-full w-full object-cover opacity-70 transition-all duration-700 group-hover:scale-105 group-hover:opacity-90" />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/95 via-background/30 to-transparent" />
                  <div className="absolute bottom-0 p-6">
                    <h3 className="text-3xl text-cream">{c.name}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{c.blurb}</p>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* WHY */}
      <section className="mx-auto max-w-7xl px-6 py-28">
        <SectionHeading eyebrow="Why Faradini" title="The Standard of Excellence" />
        <div className="grid gap-px overflow-hidden rounded-md border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f, i) => (
            <Reveal key={f.title} delay={i * 100} className="h-full">
              <div className="h-full bg-background p-8 transition-colors hover:bg-card">
                <f.icon className="text-gold" size={28} strokeWidth={1.25} />
                <h3 className="mt-6 text-2xl text-cream">{f.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{f.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ABOUT */}
      <section className="mx-auto grid max-w-7xl items-center gap-16 px-6 pb-28 md:grid-cols-2">
        <Reveal>
          <img src={craft} alt="Craftsman carving walnut" loading="lazy" width={1600} height={1008} className="aspect-[4/5] w-full rounded-md object-cover" />
        </Reveal>
        <Reveal delay={150}>
          <p className="eyebrow">Our Story</p>
          <h2 className="mt-4 text-4xl text-cream md:text-5xl">Where materials meet mastery</h2>
          <p className="mt-6 text-lg leading-relaxed text-muted-foreground">Faradini Furniture combines premium materials, skilled craftsmanship and modern design to create furniture that brings comfort, character and elegance into every space.</p>
          <Link to="/about" className="btn-outline-gold mt-10">Discover Our Story</Link>
        </Reveal>
      </section>

      {/* CUSTOM */}
      <section className="relative overflow-hidden py-32">
        <img src={craft} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/40 to-background" />
        <Reveal className="relative mx-auto max-w-3xl px-6 text-center">
          <p className="eyebrow">Custom Furniture</p>
          <h2 className="mt-4 text-5xl text-cream md:text-7xl">Made For <span className="italic text-gold-gradient">Your Space</span></h2>
          <p className="mx-auto mt-6 max-w-xl text-lg text-muted-foreground">From concept to craftsmanship, create furniture designed around your lifestyle, space and personal style.</p>
          <Link to="/contact" className="btn-gold mt-10">Request Custom Design</Link>
        </Reveal>
      </section>

      {/* SHOWROOM */}
      <section className="mx-auto max-w-7xl px-6 py-28">
        <Reveal className="relative overflow-hidden rounded-md">
          <img src={dining} alt="Faradini showroom dining setting" loading="lazy" className="h-[70vh] w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/40 to-transparent" />
          <div className="glass absolute bottom-8 left-8 right-8 max-w-lg rounded-md p-8 md:bottom-12 md:left-12">
            <p className="eyebrow">The Showroom</p>
            <h2 className="mt-3 text-4xl text-cream">Experience Faradini</h2>
            <p className="mt-4 text-muted-foreground">Discover furniture created to transform everyday spaces into extraordinary interiors.</p>
            <Link to="/contact" className="mt-6 inline-block text-xs font-semibold uppercase tracking-[0.25em] text-gold hover:text-gold-soft">Plan a visit →</Link>
          </div>
        </Reveal>
      </section>

      {/* REVIEWS */}
      <section className="bg-wood-gradient py-28">
        <div className="mx-auto max-w-7xl px-6">
          <SectionHeading eyebrow="Client Stories" title="Loved In Homes Everywhere" />
          <div className="grid gap-6 md:grid-cols-3">
            {reviews.map((r, i) => (
              <Reveal key={r.name} delay={i * 120} className="h-full">
                <figure className="glass flex h-full flex-col rounded-md p-8">
                  <div className="flex gap-1 text-gold">{Array.from({ length: 5 }).map((_, k) => <Star key={k} size={14} fill="currentColor" />)}</div>
                  <blockquote className="mt-6 flex-1 font-display text-xl italic leading-relaxed text-cream">“{r.text}”</blockquote>
                  <figcaption className="mt-6 text-sm"><span className="text-cream">{r.name}</span> <span className="text-muted-foreground">· {r.role}</span></figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="relative overflow-hidden py-32 text-center">
        <div className="pointer-events-none absolute left-1/2 top-1/2 h-96 w-[40rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold/15 blur-[120px]" />
        <Reveal className="relative mx-auto max-w-3xl px-6">
          <h2 className="text-5xl text-cream md:text-6xl">Transform Your Space With <span className="text-gold-gradient">Faradini</span></h2>
          <p className="mx-auto mt-6 max-w-xl text-lg text-muted-foreground">Discover furniture where craftsmanship meets contemporary elegance.</p>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <Link to="/shop" className="btn-gold">Shop Collection</Link>
            <Link to="/contact" className="btn-outline-gold">Contact Faradini</Link>
          </div>
        </Reveal>
      </section>
    </>
  );
}
