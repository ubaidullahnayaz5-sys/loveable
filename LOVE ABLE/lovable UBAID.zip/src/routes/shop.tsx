import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { z } from "zod";
import hero from "@/assets/hero.jpg";
import { products, categories } from "@/data/products";
import { ProductCard } from "@/components/site/ProductCard";
import { PageHero } from "@/components/site/SiteChrome";

const searchSchema = z.object({ category: z.string().optional() });

export const Route = createFileRoute("/shop")({
  validateSearch: (s) => searchSchema.parse(s),
  head: () => ({
    meta: [
      { title: "Shop Luxury Furniture — Faradini" },
      { name: "description", content: "Browse Faradini's collection of premium sofas, beds, dining tables, wardrobes and office furniture." },
      { property: "og:title", content: "Shop Luxury Furniture — Faradini" },
      { property: "og:description", content: "Browse Faradini's collection of premium handcrafted furniture." },
    ],
  }),
  component: Shop,
});

const PRICES = [
  { label: "All prices", min: 0, max: Infinity },
  { label: "Under $1,000", min: 0, max: 1000 },
  { label: "$1,000 – $5,000", min: 1000, max: 5000 },
  { label: "Over $5,000", min: 5000, max: Infinity },
];

function Shop() {
  const { category = "All" } = Route.useSearch();
  const navigate = useNavigate({ from: "/shop" });
  const [q, setQ] = useState("");
  const [price, setPrice] = useState(0);
  const [sort, setSort] = useState("featured");

  const list = useMemo(() => {
    const r = PRICES[price];
    const out = products.filter(
      (p) =>
        (category === "All" || p.category === category) &&
        p.price >= r.min && p.price < r.max &&
        (p.name + p.short).toLowerCase().includes(q.toLowerCase()),
    );
    if (sort === "low") out.sort((a, b) => a.price - b.price);
    if (sort === "high") out.sort((a, b) => b.price - a.price);
    if (sort === "name") out.sort((a, b) => a.name.localeCompare(b.name));
    return out;
  }, [category, price, sort, q]);

  return (
    <>
      <PageHero eyebrow="The Collection" title="Shop Faradini" text="Handcrafted pieces for every room, made from the finest materials." image={hero} />
      <section className="mx-auto max-w-7xl px-6 pb-28">
        <div className="glass mb-12 grid gap-4 rounded-md p-4 md:grid-cols-4">
          <label className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search furniture…" className="field !pl-9" aria-label="Search" />
          </label>
          <select value={category} onChange={(e) => navigate({ search: { category: e.target.value === "All" ? undefined : e.target.value } })} className="field" aria-label="Category">
            <option value="All">All categories</option>
            {categories.map((c) => <option key={c.name}>{c.name}</option>)}
          </select>
          <select value={price} onChange={(e) => setPrice(Number(e.target.value))} className="field" aria-label="Price">
            {PRICES.map((p, i) => <option key={p.label} value={i}>{p.label}</option>)}
          </select>
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="field" aria-label="Sort by">
            <option value="featured">Sort: Featured</option>
            <option value="low">Price: Low to High</option>
            <option value="high">Price: High to Low</option>
            <option value="name">Name: A–Z</option>
          </select>
        </div>
        <p className="mb-6 text-sm text-muted-foreground">{list.length} {list.length === 1 ? "piece" : "pieces"}</p>
        {list.length ? (
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        ) : (
          <div className="rounded-md border py-24 text-center">
            <p className="font-display text-3xl text-cream">No pieces found</p>
            <p className="mt-2 text-muted-foreground">Try a different search or contact us for a custom design.</p>
          </div>
        )}
      </section>
    </>
  );
}
