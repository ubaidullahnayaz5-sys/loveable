import { createFileRoute, Link } from "@tanstack/react-router";
import { PenTool, LayoutGrid, Truck, Wrench, Headset } from "lucide-react";
import desk from "@/assets/desk.jpg";
import { PageHero } from "@/components/site/SiteChrome";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Custom Furniture, Delivery & Installation | Faradini" },
      { name: "description", content: "Custom furniture, interior furniture solutions, delivery, installation and customer support from Faradini." },
      { property: "og:title", content: "Services — Faradini Furniture" },
      { property: "og:description", content: "Custom furniture, interior solutions, delivery, installation and support." },
    ],
  }),
  component: Services,
});

const services = [
  { icon: PenTool, t: "Custom Furniture", d: "Bespoke pieces designed around your dimensions, materials and style — from sketch to finished heirloom." },
  { icon: LayoutGrid, t: "Interior Furniture Solutions", d: "Complete furnishing plans for homes, offices and hospitality spaces, curated by our design team." },
  { icon: Truck, t: "Furniture Delivery", d: "Careful, white-glove delivery with protective packaging and scheduled time slots." },
  { icon: Wrench, t: "Installation", d: "Professional assembly and placement by trained technicians, leaving your space spotless." },
  { icon: Headset, t: "Customer Support", d: "Dedicated after-care, maintenance advice and responsive support whenever you need us." },
];

function Services() {
  return (
    <>
      <PageHero eyebrow="Our Services" title="Beyond Beautiful Furniture" text="A complete, personal service from first idea to final placement." image={desk} />
      <section className="mx-auto max-w-7xl px-6 pb-28">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <Reveal key={s.t} delay={(i % 3) * 100} className="h-full">
              <div className="group h-full rounded-md border bg-card p-10 transition-all duration-500 hover:border-gold/50 hover:shadow-glow">
                <div className="flex h-14 w-14 items-center justify-center rounded-full border border-gold/40 text-gold transition-colors group-hover:bg-gold group-hover:text-primary-foreground">
                  <s.icon size={22} strokeWidth={1.4} />
                </div>
                <h2 className="mt-8 text-3xl text-cream">{s.t}</h2>
                <p className="mt-4 leading-relaxed text-muted-foreground">{s.d}</p>
              </div>
            </Reveal>
          ))}
          <Reveal className="h-full">
            <div className="flex h-full flex-col justify-center rounded-md bg-gold-gradient p-10 text-primary-foreground">
              <h2 className="text-3xl">Start your project</h2>
              <p className="mt-3 opacity-80">Tell us about your space and we'll take it from there.</p>
              <Link to="/contact" className="mt-8 text-xs font-semibold uppercase tracking-[0.25em]">Contact us →</Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
