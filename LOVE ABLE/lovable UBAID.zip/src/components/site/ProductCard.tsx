import { Link } from "@tanstack/react-router";
import { formatPrice, type Product } from "@/data/products";

export function ProductCard({ product }: { product: Product }) {
  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-md border bg-card transition-all duration-500 hover:-translate-y-1 hover:border-gold/50 hover:shadow-glow">
      <Link to="/product/$id" params={{ id: product.id }} className="relative block aspect-[4/5] overflow-hidden">
        <img src={product.image} alt={product.name} loading="lazy" width={1024} height={1024} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
        <span className="glass absolute left-4 top-4 rounded-sm px-3 py-1 text-[0.65rem] uppercase tracking-[0.2em] text-cream">{product.category}</span>
      </Link>
      <div className="flex flex-1 flex-col p-6">
        <div className="flex items-baseline justify-between gap-4">
          <h3 className="text-2xl text-cream">{product.name}</h3>
          <span className="text-sm font-semibold text-gold">{formatPrice(product.price)}</span>
        </div>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{product.short}</p>
        <Link to="/product/$id" params={{ id: product.id }} className="mt-6 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.25em] text-gold transition-colors hover:text-gold-soft">
          View Details <span className="transition-transform group-hover:translate-x-1">→</span>
        </Link>
      </div>
    </article>
  );
}
