import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X, Phone, Mail, MapPin, MessageCircle, Instagram, Facebook } from "lucide-react";
import logo from "@/assets/logo.png.asset.json";
import { CONTACT, whatsappLink } from "@/data/products";

export const NAV = [
  { to: "/", label: "Home" },
  { to: "/shop", label: "Shop" },
  { to: "/categories", label: "Categories" },
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
  { to: "/contact", label: "Contact" },
] as const;

export function Logo({ size = "h-12" }: { size?: string }) {
  return (
    <Link to="/" className="flex items-center gap-3" aria-label="Faradini Furniture home">
      <img src={logo.url} alt="" className={`${size} w-auto rounded-sm`} />
      <span className="leading-none">
        <span className="block font-display text-xl tracking-[0.18em] text-gold-gradient">FARADINI</span>
        <span className="block text-[0.55rem] tracking-[0.5em] text-muted-foreground">FURNITURE</span>
      </span>
    </Link>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 30);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled || open ? "glass border-x-0 border-t-0" : "border-b border-transparent"}`}>
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-3">
        <Logo />
        <nav className="hidden items-center gap-9 lg:flex">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to} activeOptions={{ exact: n.to === "/" }} className="text-xs uppercase tracking-[0.22em] text-cream/80 transition-colors hover:text-gold data-[status=active]:text-gold">
              {n.label}
            </Link>
          ))}
        </nav>
        <Link to="/contact" className="btn-gold hidden !px-5 !py-3 lg:inline-flex">Visit Showroom</Link>
        <button className="text-cream lg:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav className="flex flex-col gap-1 px-6 pb-6 lg:hidden">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} activeOptions={{ exact: n.to === "/" }} className="border-b py-3 font-display text-2xl text-cream data-[status=active]:text-gold">
              {n.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t bg-wood-gradient">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-16 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo size="h-16" />
          <p className="mt-6 font-display text-2xl italic text-cream/90">Crafting Comfort. Creating Elegance.</p>
          <div className="mt-6 flex gap-4 text-gold">
            <a href="#" aria-label="Instagram" className="hover:text-gold-soft"><Instagram size={20} /></a>
            <a href="#" aria-label="Facebook" className="hover:text-gold-soft"><Facebook size={20} /></a>
            <a href={whatsappLink()} target="_blank" rel="noreferrer" aria-label="WhatsApp" className="hover:text-gold-soft"><MessageCircle size={20} /></a>
          </div>
        </div>
        <div>
          <p className="eyebrow mb-5">Quick Links</p>
          <ul className="space-y-3 text-sm">
            {NAV.map((n) => (
              <li key={n.to}><Link to={n.to} className="text-muted-foreground hover:text-gold">{n.label}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <p className="eyebrow mb-5">Contact</p>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex gap-3"><Phone size={16} className="mt-0.5 text-gold" />{CONTACT.phone}</li>
            <li className="flex gap-3"><MessageCircle size={16} className="mt-0.5 text-gold" /><a href={whatsappLink()} target="_blank" rel="noreferrer" className="hover:text-gold">WhatsApp us</a></li>
            <li className="flex gap-3"><Mail size={16} className="mt-0.5 text-gold" />{CONTACT.email}</li>
            <li className="flex gap-3"><MapPin size={16} className="mt-0.5 text-gold" />{CONTACT.address}</li>
          </ul>
        </div>
      </div>
      <div className="border-t py-6 text-center text-xs tracking-[0.2em] text-muted-foreground">
        © {new Date().getFullYear()} FARADINI FURNITURE · ALL RIGHTS RESERVED
      </div>
    </footer>
  );
}

export function PageHero({ eyebrow, title, text, image }: { eyebrow: string; title: string; text: string; image: string }) {
  return (
    <section className="relative flex min-h-[60vh] items-end overflow-hidden pb-20 pt-40">
      <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/20" />
      <div className="relative mx-auto w-full max-w-7xl px-6">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="mt-4 max-w-3xl text-5xl text-cream md:text-7xl">{title}</h1>
        <p className="mt-6 max-w-xl text-lg text-muted-foreground">{text}</p>
      </div>
    </section>
  );
}
