import sofa from "@/assets/sofa.jpg";
import bed from "@/assets/bed.jpg";
import dining from "@/assets/dining.jpg";
import chair from "@/assets/chair.jpg";
import wardrobe from "@/assets/wardrobe.jpg";
import desk from "@/assets/desk.jpg";
import craft from "@/assets/craft.jpg";
import hero from "@/assets/hero.jpg";

// Placeholder contact details — replace with real business info.
export const CONTACT = {
  phone: "+92 300 0000000",
  whatsapp: "923000000000",
  email: "hello@faradini.com",
  address: "Showroom address, City, Country",
  hours: "Mon – Sat: 10:00 – 20:00 · Sun: Closed",
};

export const whatsappLink = (text = "Hello Faradini, I'd like to inquire about your furniture.") =>
  `https://wa.me/${CONTACT.whatsapp}?text=${encodeURIComponent(text)}`;

export type Category = "Living Room" | "Bedroom" | "Dining Room" | "Office Furniture" | "Custom Furniture" | "Home Décor";

export type Product = {
  id: string;
  name: string;
  short: string;
  description: string;
  price: number;
  category: Category;
  image: string;
  gallery: string[];
  material: string;
  dimensions: string;
  colors: { name: string; value: string }[];
};

const colors = [
  { name: "Walnut", value: "oklch(0.38 0.06 50)" },
  { name: "Espresso", value: "oklch(0.24 0.03 45)" },
  { name: "Ivory", value: "oklch(0.92 0.03 85)" },
];

export const products: Product[] = [
  { id: "luxury-sofa", name: "Luxury Sofa", short: "Sculpted bouclé on a solid walnut plinth.", description: "A softly curved silhouette upholstered in premium bouclé, resting on a hand-finished walnut base. Designed to anchor a living room with quiet presence.", price: 4200, category: "Living Room", image: sofa, gallery: [sofa, hero], material: "Italian bouclé, solid walnut", dimensions: "240 × 95 × 78 cm", colors },
  { id: "modern-bed", name: "Modern Bed", short: "Upholstered headboard, floating walnut frame.", description: "A low, floating frame in American walnut with a channel-tufted linen headboard — calm, generous and built to last generations.", price: 3600, category: "Bedroom", image: bed, gallery: [bed, wardrobe], material: "American walnut, Belgian linen", dimensions: "200 × 220 × 110 cm", colors },
  { id: "executive-dining-table", name: "Executive Dining Table", short: "Monolithic walnut top seating eight.", description: "A substantial slab of book-matched walnut on a sculptural pedestal base. Made for long dinners and lasting conversations.", price: 5800, category: "Dining Room", image: dining, gallery: [dining, craft], material: "Book-matched walnut veneer, solid core", dimensions: "260 × 105 × 76 cm", colors },
  { id: "classic-wooden-chair", name: "Classic Wooden Chair", short: "Hand-carved arms, saddle leather seat.", description: "A heritage armchair with hand-carved scrolled arms and a full-grain leather seat, finished by our master woodworkers.", price: 890, category: "Dining Room", image: chair, gallery: [chair, craft], material: "Solid walnut, full-grain leather", dimensions: "62 × 58 × 92 cm", colors },
  { id: "premium-wardrobe", name: "Premium Wardrobe", short: "Floor-to-ceiling walnut with brass pulls.", description: "Six-door wardrobe in rich dark walnut with solid brass pulls, soft-close hinges and fully customisable interiors.", price: 6400, category: "Bedroom", image: wardrobe, gallery: [wardrobe, bed], material: "Walnut veneer, solid brass hardware", dimensions: "300 × 62 × 240 cm", colors },
  { id: "luxury-office-desk", name: "Luxury Office Desk", short: "Executive walnut desk with brass detailing.", description: "A commanding executive desk with a hand-polished walnut top, integrated storage and brushed brass accents.", price: 4900, category: "Office Furniture", image: desk, gallery: [desk, craft], material: "Solid walnut, brushed brass", dimensions: "200 × 90 × 76 cm", colors },
];

export const categories: { name: Category; image: string; blurb: string }[] = [
  { name: "Living Room", image: hero, blurb: "Sofas, lounge chairs & tables" },
  { name: "Bedroom", image: bed, blurb: "Beds, wardrobes & nightstands" },
  { name: "Dining Room", image: dining, blurb: "Tables, chairs & sideboards" },
  { name: "Office Furniture", image: desk, blurb: "Desks, storage & seating" },
  { name: "Custom Furniture", image: craft, blurb: "Designed around your space" },
  { name: "Home Décor", image: wardrobe, blurb: "Finishing touches & lighting" },
];

export const formatPrice = (n: number) => `$${n.toLocaleString("en-US")}`;
